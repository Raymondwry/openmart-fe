export interface DataItem {
    id: number;
    name: string;
    reviews: number;
    start_date: string;
    picture: string;
  }