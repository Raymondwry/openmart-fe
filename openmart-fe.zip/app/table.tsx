"use client";

import React, { useState } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Space,
  Row,
  Col,
  DatePicker,
  message,
} from "antd";
import moment from "moment";
import useData from "./useData";
import { DataItem } from "./table.types";
import SearchBar from "./searchBar";

const AppTable = () => {
  const [editingItem, setEditingItem] = useState<DataItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form] = Form.useForm();
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);

  const {
    data,
    total,
    loading,
    pagination,
    search,
    searchColumn,
    sorter,
    setSearchColumn,
    handleDelete,
    handleSave,
    handleTableChange,
    handleSearch,
    handleClearSearch,
    setSearch,
  } = useData();

  const columns = [
    {
      key: "order",
      width: 200,
      render: (_, __, index) => (
        <div style={{ width: 200, height: 34 }}>{index + 1}</div>
      ),
    },
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
      width: 200,
      sorter: (a, b) => a.id - b.id,
      sortOrder: sorter.field === "id" && sorter.order,
      render: (text) => <div style={{ width: 200, height: 34 }}>{text}</div>,
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      width: 200,
      sorter: (a, b) => a.name.localeCompare(b.name),
      sortOrder: sorter.field === "name" && sorter.order,
      render: (text) => <div style={{ width: 200, height: 34 }}>{text}</div>,
    },
    {
      title: "Reviews",
      dataIndex: "reviews",
      key: "reviews",
      width: 200,
      sorter: (a, b) => a.reviews - b.reviews,
      sortOrder: sorter.field === "reviews" && sorter.order,
      className: "text-right",
      render: (text) => <div style={{ width: 200, height: 34 }}>{text}</div>,
    },
    {
      title: "Start Date",
      dataIndex: "start_date",
      key: "start_date",
      width: 200,
      sorter: (a, b) =>
        moment(a.start_date).unix() - moment(b.start_date).unix(),
      sortOrder: sorter.field === "start_date" && sorter.order,
      render: (text) => (
        <div style={{ width: 200, height: 34 }}>
          {moment(text).format("YYYY-MM-DD")}
        </div>
      ),
    },
    {
      title: "Picture",
      dataIndex: "picture",
      key: "picture",
      width: 200,
      render: (text) => (
        <div style={{ width: 200, height: 34 }}>
          <a href={text} target="_blank" rel="noopener noreferrer">
            {text}
          </a>
        </div>
      ),
    },
    {
      title: "Action",
      key: "action",
      width: 200,
      render: (_, record: DataItem) => (
        <Space size="middle">
          <Button onClick={() => handleEdit(record)}>Edit</Button>
          <Button onClick={() => handleDelete(record.id)}>Delete</Button>
        </Space>
      ),
    },
  ];

  const handleAdd = () => {
    setEditingItem(null);
    form.resetFields();
    setIsModalOpen(true);
  };

  const handleEdit = (record: DataItem) => {
    setEditingItem(record);
    form.setFieldsValue({
      ...record,
      start_date: moment(record.start_date),
    });
    setIsModalOpen(true);
  };

  const handleSaveData = async () => {
    try {
      const values = await form.validateFields();
      await handleSave(values, editingItem);
      setIsModalOpen(false);
    } catch (error) {
      console.error("Error validating fields:", error);
    }
  };

  const handleDeleteSelected = async () => {
    try {
      await Promise.all(
        selectedRowKeys.map((key) => handleDelete(key as number))
      );
      setSelectedRowKeys([]);
      message.success("Selected items deleted successfully");
    } catch (error) {
      message.error("Error deleting selected items");
    }
  };

  return (
    <div className="p-4" style={{ margin: "20px" }}>
      <Row gutter={16} className="mb-4" justify="space-between">
        <Col>
          <SearchBar
            searchColumn={searchColumn}
            setSearchColumn={setSearchColumn}
            search={search}
            setSearch={setSearch}
            handleSearch={handleSearch}
            handleClearSearch={handleClearSearch}
          />
        </Col>
        <Col>
          <Space>
            <span>
              {selectedRowKeys.length} / {data.length} rows selected
            </span>
            <Button
              onClick={handleDeleteSelected}
              disabled={selectedRowKeys.length === 0}
              type="primary"
              danger
            >
              Delete Selected
            </Button>
          </Space>
        </Col>
      </Row>
      <Table
        columns={columns}
        dataSource={data}
        rowKey="id"
        pagination={{ ...pagination, total }}
        loading={loading}
        onChange={handleTableChange}
        rowSelection={{
          selectedRowKeys,
          onChange: setSelectedRowKeys,
        }}
        className="custom-table"
        style={{ padding: "15px" }}
      />
      <Button onClick={handleAdd} className="border-none hover:bg-gray-500">
        Add Item
      </Button>
      <Modal
        title={editingItem ? "Edit Item" : "Add Item"}
        visible={isModalOpen}
        onOk={handleSaveData}
        onCancel={() => setIsModalOpen(false)}
      >
        <Form form={form} layout="vertical">
          <Form.Item
            name="name"
            label="Name"
            rules={[{ required: true, message: "Please enter name" }]}
          >
            <Input className="w-full" />
          </Form.Item>
          <Form.Item
            name="reviews"
            label="Reviews"
            rules={[{ required: true, message: "Please enter reviews" }]}
          >
            <Input type="number" min={0} className="w-full" />
          </Form.Item>
          <Form.Item
            name="start_date"
            label="Start Date"
            rules={[{ required: true, message: "Please enter start date" }]}
          >
            <DatePicker style={{ width: "100%" }} className="w-full" />
          </Form.Item>
          <Form.Item
            name="picture"
            label="Picture"
            rules={[
              {
                required: true,
                message: "Please enter picture URL",
                type: "url",
              },
            ]}
          >
            <Input className="w-full" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default AppTable;
