import React from 'react';
import AppTable from '../app/table';

export default function Home() {
  return (
    <div className="container mx-auto px-4">
      <AppTable />
    </div>
  );
}
