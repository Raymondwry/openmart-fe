import withTM from 'next-transpile-modules';

const transpileModules = ['rc-pagination', 'antd', '@ant-design/icons', 'rc-util'];

const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  webpack: (config) => {
    return config;
  },
};

export default withTM(transpileModules)(nextConfig);
